# Cloud Idea

A landing page with responsive layout.

Technologies: HTML5 and CSS.